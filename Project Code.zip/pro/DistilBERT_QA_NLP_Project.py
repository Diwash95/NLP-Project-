from datasets import load_dataset
dataset = load_dataset('squad_v2', split='train')

#import libraries
from transformers import DistilBertTokenizer, DistilBertForQuestionAnswering
import torch

def ROBERTA(questions, answer):
  # define the distilBERT tokenizer
  tokenizer = DistilBertTokenizer.from_pretrained("distilbert-base-uncased")
  model = DistilBertForQuestionAnswering.from_pretrained("distilbert-base-uncased")

  # run the modeel on the dataset to get preds
  preds = []
  for qa in dataset:
    inputs = tokenizer(qa['question'], qa['context'], return_tensors="pt")
    with torch.no_grad():
      outputs = model(**inputs)
    answer_start_index = outputs.start_logits.argmax()
    answer_end_index = outputs.end_logits.argmax()
    predict_answer_tokens = inputs.input_ids[0, answer_start_index: answer_end_index + 1]
    x = tokenizer.decode(predict_answer_tokens)
    preds.append(x)

  val = preds
  # functions to compute f1 score and exact match score
  def normalize_answer(s):
    """Lower text and remove punctuation, articles and extra whitespace."""

    def remove_articles(text):
      regex = re.compile(r'\b(a|an|the)\b', re.UNICODE)
      return re.sub(regex, ' ', text)

    def white_space_fix(text):
      return ' '.join(text.split())

    def remove_punc(text):
      exclude = set(string.punctuation)
      return ''.join(ch for ch in text if ch not in exclude)

    def lower(text):
      return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))

  def get_tokens(s):
    if not s: return []
    return normalize_answer(s).split()

  def compute_exact(a_gold, a_pred):
    return int(normalize_answer(a_gold) == normalize_answer(a_pred))

  return val

