
import torch
from torch.utils.data import DataLoader, RandomSampler, SequentialSampler
from transformers.data.processors.squad import SquadResult, SquadV2Processor, SquadExample
from transformers.data.metrics.squad_metrics import compute_predictions_logits

def GPT2(questions, context):
    def intoList(tensor):
        return tensor.detach().cpu().tolist()

    # for running predictions on given models
    def run_prediction(model, model_name, tokenizer, question_texts, context_text):
        processor = SquadV2Processor()
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        # setting configuration
        n_best_size = 1
        max_answer_length = 30
        do_lower_case = True
        null_score_diff_threshold = 0.0
        """Setup function to compute predictions"""
        examples = []
        for i, question_text in enumerate(question_texts):
            example = SquadExample(
                qas_id=str(i),
                question_text=question_text,
                context_text=context_text,
                answer_text=None,
                start_position_character=None,
                title="Predict",
                is_impossible=False,
                answers=None,
            )
            examples.append(example)
        features, dataset = squad_convert_examples_to_features(
            examples=examples,
            tokenizer=tokenizer,
            max_seq_length=384,
            doc_stride=128,
            max_query_length=64,
            is_training=False,
            return_dataset="pt",
            threads=1,
        )
        sampler = SequentialSampler(dataset)
        Dataloader = DataLoader(dataset, sampler=sampler, batch_size=10)
        all_results = []
        for batch in Dataloader:
            model.eval()
            batch = tuple(t.to(device) for t in batch)
            with torch.no_grad():
                inputs = {
                    "input_ids": batch[0],
                    "attention_mask": batch[1],
                    "token_type_ids": batch[2],
                }
                example_indices = batch[3]
                outputs = model(**inputs)
                for i, example_index in enumerate(example_indices):
                    eval_feature = features[example_index.item()]
                    unique_id = int(eval_feature.unique_id)
                    output = [intoList(output[i]) for output in outputs]
                    start_logits, end_logits = output
                    result = SquadResult(unique_id, start_logits, end_logits)
                    all_results.append(result)

        Pred_File = model_name + "_predictions.json"
        nbest_file = model_name + "_nbest_predictions.json"
        outputnulllogoddsfile = model_name + "_null_predictions.json"
        predictions = compute_predictions_logits(
            examples,
            features,
            all_results,
            n_best_size,
            max_answer_length,
            do_lower_case,
            Pred_File,
            nbest_file,
            outputnulllogoddsfile,
            False,
            True,
            null_score_diff_threshold,
            tokenizer,
        )
        return predictions

    # In[51]:

    # gpt2 model
    def runGpt2(model, question_texts, context_text):
        predictions = []
        for question in question_texts:
            prediction = model(question=question, context=context_text)
            predictions.append(prediction['answer'])
        return predictions

    from transformers import pipeline
    # for using pretrained gpt2 model
    gpt2_model = pipeline('question-answering')

    # In[53]:

    # given dataset to test model
    #corpus = "Musk was born to a Canadian mother and White South African father, and raised in Pretoria, South Africa. He briefly attended the University of Pretoria before moving to Canada at age 17 to avoid conscription. He was enrolled at Queen's University and transferred to the University of Pennsylvania two years later, where he received a bachelor's degree in economics and physics. He moved to California in 1995 to attend Stanford University but decided instead to pursue a business career, co-founding the web software company Zip2 with his brother Kimbal. The startup was acquired by Compaq for $307 million in 1999. The same year, Musk co-founded online bank X.com, which merged with Confinity in 2000 to form PayPal. The company was bought by eBay in 2002 for $1.5 billion."
    #query = ["What is startup by elon musk?"]

    val = runGpt2(gpt2_model, questions, context)

    return val




