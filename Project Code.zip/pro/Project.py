import streamlit as st
from NLP_ALBERT import ALBERT
from NLP_BERT import BERT
from GPT2withAccuracyscore import GPT2
from DistilBERT_QA_NLP_Project import ROBERTA
st.title('NLP - Project : Question and Answering ')

def model_question(model,context,question):
    if model == 'BERT':
        # write the BERT file
        answer = BERT(question,context)
        return answer 
    elif model == 'ALBERT':
        # write the ALBERT file
        answer = ALBERT(question,context)
        return answer 
    elif model == 'GPT2':
        # write the GPT2 file
        answer = GPT2(question,context)
        return answer 
    elif model == 'Roberta_Squad':
        # write the Roberta_Squad file
        answer = ROBERTA(question,context)
        return answer 

model = st.radio(
     "Select the model to run the Question and Answer : ",
     ('BERT', 'ALBERT', 'GPT2','Roberta_Squad'))
if model == 'BERT':
     st.write('BERT model is selected')
elif model == 'ALBERT':
    st.write('ALBERT model is selected')
elif model == 'GPT2':
     st.write("GPT2 model is selected")
elif model == 'Roberta_Squad':
     st.write("Roberta_Squad model is selected")
else:
    st.write("Please select the model")

para_txt = st.text_area('Enter the Context : ',)
print(para_txt)
if len(para_txt) > 0:
    st.write('The Context is Entered')
else:
    st.write('Context not Entered')

ques = st.text_input('Enter the Question : ')
if len(ques) > 0:
    st.write('Entered Question : ',ques)
else:
    st.write('Question not given ')

ans=model_question(model,para_txt,ques)

st.write(ans)# The response answer is reflected in the webpage.